import React, { useState, useMemo, useEffect } from 'react';
import { 
  ArrowLeftRight, 
  MapPin, 
  Search, 
  Calendar, 
  Building2, 
  Clock, 
  DollarSign, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  ShieldAlert, 
  ExternalLink, 
  Copy, 
  Check, 
  Filter, 
  Navigation, 
  UserCheck, 
  Phone, 
  FileText,
  RotateCcw,
  X,
  ChevronRight,
  Info,
  Tag
} from 'lucide-react';
import { Store, SOSchedule, AuditorPersonnel } from '../../types/stockOpname';
import { calculateHaversineDistance, calculateHaversineDistanceBetweenStores, resolveStoreCoordinates } from '../../utils/geoUtils';
import { 
  getCurrentCalendarMonth, 
  getCurrentCalendarYear, 
  getFullMonthNameIndo, 
  formatRupiah, 
  formatDateIndo, 
  formatSmartSODate, 
  formatZoneText 
} from '../../utils/formatters';
import { 
  isStoreZonaHitam, 
  isStoreSOAktiva, 
  getSOAktivaLabel, 
  getCleanTypeSo,
  extractStoreSODateForPeriod,
  MASTER_BALI_MONTH_CONFIGS,
  getMasterStoresMonthStats 
} from '../../utils/storeSyncUtils';

interface StoreRelocationAssistantProps {
  stores: Store[];
  schedules: SOSchedule[];
  personnel?: AuditorPersonnel[];
  selectedMonth?: string;
  selectedYear?: string;
  onApplyRelocation: (
    originalScheduleId: string,
    actionType: 'Pindah Toko' | 'Gagal SO',
    reason: string,
    replacementDetails?: {
      newStore: Store;
      newDate: string;
      newTime: string;
    }
  ) => void;
  onClose?: () => void;
}

// Helper to extract clean Kabupaten name
export const getCleanKabupaten = (store?: Partial<Store> | null): string => {
  if (!store) return '';
  const raw = store.kabupaten || store.city || store.region || '';
  if (!raw) return '';
  let clean = raw.trim().toUpperCase().replace(/^(KABUPATEN|KAB\.?|KOTA)\s+/i, '').trim();
  if (clean.startsWith('KAB ') || clean.startsWith('KAB. ')) {
    clean = clean.replace(/^KAB\.?\s+/i, '').trim();
  }
  return clean;
};

// Helper to extract clean Kecamatan name
export const getCleanKecamatan = (store?: Partial<Store> | null): string => {
  if (!store) return '';
  const raw = store.kecamatan || store.district || '';
  if (!raw) return '';
  let clean = raw.trim().toUpperCase().replace(/^(KECAMATAN|KEC\.?)\s+/i, '').trim();
  if (clean.startsWith('KEC ') || clean.startsWith('KEC. ')) {
    clean = clean.replace(/^KEC\.?\s+/i, '').trim();
  }
  return clean;
};

export interface CandidateStoreRecommendation {
  store: Store;
  distanceKm: number;
  scheduleStatusType: 'BELUM_TERJADWAL' | 'TERJADWAL_LAIN' | 'SUDAH_SO' | 'HARI_INI';
  scheduledDateMaster?: string;
  activeSchedule?: SOSchedule;
  typeSo: string;
  zona: string;
  isZonaHitam: boolean;
  saldoToko: number | string;
  kasToko?: number;
  soAktiva?: string;
  am?: string;
  as?: string;
  korlap?: string;
  coordinatesAvailable: boolean;
}

export const RELOCATION_MONTH_OPTIONS = [
  { value: '10', label: '10 - Oktober (Bulan Berjalan)' },
  { value: '09', label: '09 - September' },
  { value: '08', label: '08 - Agustus' },
  { value: '11', label: '11 - November' },
  { value: '12', label: '12 - Desember' },
  { value: '07', label: '07 - Juli' },
  { value: '06', label: '06 - Juni' },
  { value: '05', label: '05 - Mei' },
  { value: '04', label: '04 - April' },
  { value: '03', label: '03 - Maret' },
  { value: '02', label: '02 - Februari' },
  { value: '01', label: '01 - Januari' },
  { value: 'ALL', label: 'Semua Bulan' }
];

export const StoreRelocationAssistant: React.FC<StoreRelocationAssistantProps> = ({
  stores,
  schedules,
  personnel = [],
  selectedMonth,
  selectedYear,
  onApplyRelocation,
  onClose
}) => {
  // Pre-calculate scheduling statistics across all months from Master Toko Bali stores
  const monthStats = useMemo(() => {
    return getMasterStoresMonthStats(stores);
  }, [stores]);

  const defaultCalM = getCurrentCalendarMonth();
  const defaultCalY = getCurrentCalendarYear();

  // Smart initial month resolution:
  // 1. If passed selectedMonth has scheduled stores in Master Toko Bali, use it
  // 2. If October (10) has scheduled stores in Master Toko Bali, default to October
  // 3. If current calendar month has stores, use it
  // 4. Otherwise pick the month with highest scheduled store count
  const [selectedRelocationMonth, setSelectedRelocationMonth] = useState<string>(() => {
    if (selectedMonth && selectedMonth !== 'ALL' && monthStats[selectedMonth]?.scheduledCount > 0) {
      return selectedMonth;
    }
    if (monthStats['10'] && monthStats['10'].scheduledCount > 0) {
      return '10';
    }
    if (monthStats[defaultCalM] && monthStats[defaultCalM].scheduledCount > 0) {
      return defaultCalM;
    }
    const sorted = Object.values(monthStats).sort((a, b) => b.scheduledCount - a.scheduledCount);
    if (sorted[0] && sorted[0].scheduledCount > 0) {
      return sorted[0].month;
    }
    return selectedMonth && selectedMonth !== 'ALL' ? selectedMonth : (defaultCalM || '10');
  });

  const [selectedRelocationYear, setSelectedRelocationYear] = useState<string>(() => {
    if (selectedYear && selectedYear !== 'ALL') return selectedYear;
    return defaultCalY || '2026';
  });

  // Keep state synchronized if selectedMonth prop updates from outside
  useEffect(() => {
    if (selectedMonth && selectedMonth !== 'ALL' && selectedMonth !== selectedRelocationMonth) {
      setSelectedRelocationMonth(selectedMonth);
    }
  }, [selectedMonth]);

  // Step 1: Selected Source Store (Toko yang minta pindah)
  const [selectedSourceScheduleId, setSelectedSourceScheduleId] = useState<string>('');
  const [sourceSearchQuery, setSourceSearchQuery] = useState<string>('');
  const [sourceFilterDate, setSourceFilterDate] = useState<string>('ALL');
  const [sourceFilterKabupaten, setSourceFilterKabupaten] = useState<string>('ALL');
  const [sourceFilterStatus, setSourceFilterStatus] = useState<'ALL' | 'NEED_RELOCATION' | 'ACTIVE'>('ALL');
  
  // Step 2: Reason & Date Configuration
  const [reasonCategory, setReasonCategory] = useState<string>('Akses Jalan / Cuaca Ekstrem');
  const [customReason, setCustomReason] = useState<string>('');
  const [targetDateForReplacement, setTargetDateForReplacement] = useState<string>('');
  const [targetTimeForReplacement, setTargetTimeForReplacement] = useState<string>('21:00');

  // Step 3: Recommendation Filters & Sort Mode
  const [candidateSearchQuery, setCandidateSearchQuery] = useState<string>('');
  const [filterScheduleType, setFilterScheduleType] = useState<'ALL' | 'BELUM_TERJADWAL' | 'TERJADWAL_LAIN'>('ALL');
  const [candidateSortMode, setCandidateSortMode] = useState<'NEAREST_GPS' | 'PRIORITY_UNASSIGNED' | 'HIGHEST_SALDO'>('NEAREST_GPS');
  const [filterKabupaten, setFilterKabupaten] = useState<string>('ALL');
  const [filterKecamatan, setFilterKecamatan] = useState<string>('ALL');
  const [filterTypeSo, setFilterTypeSo] = useState<string>('ALL');
  const [filterSoAktiva, setFilterSoAktiva] = useState<'ALL' | 'SO_AKTIVA' | 'NON_SO_AKTIVA'>('ALL');
  const [filterZonaOnly, setFilterZonaOnly] = useState<boolean>(false);
  const [maxRadiusKm, setMaxRadiusKm] = useState<number>(35);
  const [selectedCandidateStoreId, setSelectedCandidateStoreId] = useState<string>('');
  const [copiedWA, setCopiedWA] = useState<boolean>(false);

  // Success Confirmation State
  const [swapExecuted, setSwapExecuted] = useState<{
    originalStore: Store;
    replacementStore: Store;
    date: string;
    reason: string;
  } | null>(null);

  // All non-archived schedules eligible for relocation
  const eligibleSourceSchedules = useMemo(() => {
    return schedules.filter(s => s.status !== 'Dibatalkan');
  }, [schedules]);

  // Unique dates from active schedules within selected relocation month
  const availableScheduleDates = useMemo(() => {
    const dates = new Set<string>();
    eligibleSourceSchedules.forEach(s => {
      if (s.scheduledDate) {
        if (selectedRelocationMonth === 'ALL' || s.scheduledDate.split('-')[1] === selectedRelocationMonth) {
          dates.add(s.scheduledDate);
        }
      }
    });
    return Array.from(dates).sort();
  }, [eligibleSourceSchedules, selectedRelocationMonth]);

  // Filtered source schedules (strictly respects selected relocation month)
  const filteredSourceSchedules = useMemo(() => {
    return eligibleSourceSchedules.filter(s => {
      if (sourceFilterStatus === 'NEED_RELOCATION') {
        const isNeed = s.status === 'Pindah Toko' || s.status === 'Gagal SO';
        if (!isNeed) return false;
      } else if (sourceFilterStatus === 'ACTIVE') {
        const isActive = s.status === 'Terjadwal' || s.status === 'Proses SO' || s.status === 'Menunggu Rekapan';
        if (!isActive) return false;
      }

      // Filter by selected relocation month
      if (selectedRelocationMonth !== 'ALL') {
        const scMonth = s.scheduledDate ? s.scheduledDate.split('-')[1] : '';
        if (scMonth && scMonth !== selectedRelocationMonth) return false;
      }

      if (sourceFilterDate !== 'ALL' && s.scheduledDate !== sourceFilterDate) return false;
      
      if (sourceFilterKabupaten !== 'ALL') {
        const matchedStore = stores.find(st => st.id === s.storeId || st.code === s.storeCode);
        const storeKab = getCleanKabupaten(matchedStore) || s.region;
        const matchesKab = storeKab === sourceFilterKabupaten || storeKab.includes(sourceFilterKabupaten) || sourceFilterKabupaten.includes(storeKab);
        if (!matchesKab) return false;
      }

      if (sourceSearchQuery.trim()) {
        const q = sourceSearchQuery.toLowerCase();
        return (
          s.storeCode.toLowerCase().includes(q) ||
          s.storeName.toLowerCase().includes(q) ||
          s.region.toLowerCase().includes(q) ||
          (s.officerInCharge && s.officerInCharge.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [eligibleSourceSchedules, sourceFilterStatus, selectedRelocationMonth, sourceFilterDate, sourceFilterKabupaten, sourceSearchQuery, stores]);

  // Count schedules that specifically requested relocation
  const needRelocationCount = useMemo(() => {
    return filteredSourceSchedules.filter(s => s.status === 'Pindah Toko' || s.status === 'Gagal SO').length;
  }, [filteredSourceSchedules]);

  // Auto-select first schedule from filtered list
  useEffect(() => {
    if (filteredSourceSchedules.length > 0) {
      const stillValid = filteredSourceSchedules.some(s => s.id === selectedSourceScheduleId);
      if (!stillValid) {
        const urgent = filteredSourceSchedules.find(s => s.status === 'Pindah Toko' || s.status === 'Gagal SO');
        if (urgent) {
          setSelectedSourceScheduleId(urgent.id);
        } else if (filteredSourceSchedules[0]) {
          setSelectedSourceScheduleId(filteredSourceSchedules[0].id);
        }
      }
    } else {
      setSelectedSourceScheduleId('');
    }
  }, [filteredSourceSchedules, selectedSourceScheduleId]);

  // Currently Selected Source Schedule & Store
  const selectedSchedule = useMemo(() => {
    return filteredSourceSchedules.find(s => s.id === selectedSourceScheduleId) || filteredSourceSchedules[0] || null;
  }, [filteredSourceSchedules, selectedSourceScheduleId]);

  const selectedSourceStore = useMemo(() => {
    if (!selectedSchedule) return null;
    return stores.find(st => st.id === selectedSchedule.storeId || st.code === selectedSchedule.storeCode) || null;
  }, [selectedSchedule, stores]);

  // Auto-fill target date when selected schedule changes
  React.useEffect(() => {
    if (selectedSchedule) {
      setTargetDateForReplacement(selectedSchedule.scheduledDate || '');
      setTargetTimeForReplacement(selectedSchedule.scheduledTime || '21:00');
    }
  }, [selectedSchedule]);

  const activeTargetMonth = (selectedRelocationMonth && selectedRelocationMonth !== 'ALL')
    ? selectedRelocationMonth
    : (selectedSchedule?.scheduledDate ? selectedSchedule.scheduledDate.split('-')[1] : (defaultCalM || '10'));
  const activeTargetYear = (selectedRelocationYear && selectedRelocationYear !== 'ALL')
    ? selectedRelocationYear
    : (selectedSchedule?.scheduledDate ? selectedSchedule.scheduledDate.split('-')[0] : (defaultCalY || '2026'));

  // Active column configuration for Master Toko Bali (SO OKTOBER, SO SEPTEMBER, SO AGUSTUS, dll.)
  const activeMonthConfig = useMemo(() => {
    return MASTER_BALI_MONTH_CONFIGS.find(c => c.month === activeTargetMonth) || {
      month: activeTargetMonth,
      name: getFullMonthNameIndo(activeTargetMonth),
      standardCol: `SO ${getFullMonthNameIndo(activeTargetMonth).toUpperCase()} '26`,
      prop: 'soOktober'
    };
  }, [activeTargetMonth]);

  // Build candidate stores recommendations with accurate distance and schedule status
  const candidateRecommendations = useMemo<CandidateStoreRecommendation[]>(() => {
    if (!selectedSourceStore) return [];

    const currentDate = selectedSchedule?.scheduledDate || '';

    // Create lookup for schedules by store code strictly within active target month
    const scheduleByStoreCode = new Map<string, SOSchedule>();
    schedules.forEach(sc => {
      if (sc.status !== 'Dibatalkan' && sc.status !== 'Gagal SO') {
        const scMonth = sc.scheduledDate ? sc.scheduledDate.split('-')[1] : '';
        if (!activeTargetMonth || activeTargetMonth === 'ALL' || scMonth === activeTargetMonth) {
          scheduleByStoreCode.set(sc.storeCode, sc);
        }
      }
    });

    const list: CandidateStoreRecommendation[] = [];

    stores.forEach(st => {
      // Exclude source store itself
      if (st.id === selectedSourceStore.id || st.code === selectedSourceStore.code) return;

      // Accurate Haversine Distance calculation between stores
      const dist = calculateHaversineDistanceBetweenStores(selectedSourceStore, st);
      const coordInfo = resolveStoreCoordinates(st);
      const hasCoordinates = !coordInfo.isEstimated || coordInfo.precision === 'KECAMATAN';

      // Determine schedule status in master & schedule table for active target month (Oktober/September/dll.)
      const activeSched = scheduleByStoreCode.get(st.code);
      let scheduleStatusType: 'BELUM_TERJADWAL' | 'TERJADWAL_LAIN' | 'SUDAH_SO' | 'HARI_INI' = 'BELUM_TERJADWAL';
      
      const masterExtract = extractStoreSODateForPeriod(st, activeTargetMonth, activeTargetYear);
      let directMonthCol = '';
      if (activeTargetMonth === '10') directMonthCol = st.soOktober || '';
      else if (activeTargetMonth === '09') directMonthCol = st.soSeptember || '';
      else if (activeTargetMonth === '08') directMonthCol = st.soAgustus || '';
      else if (activeTargetMonth === '11') directMonthCol = st.soNovember || '';
      else if (activeTargetMonth === '12') directMonthCol = st.soDesember || '';
      else if (activeTargetMonth === '07') directMonthCol = st.tglSoJuli || '';
      else if (activeTargetMonth === '06') directMonthCol = st.tglSoJuni || '';
      else if (activeTargetMonth === '05') directMonthCol = st.tglSoMei || '';
      else if (activeTargetMonth === '04') directMonthCol = st.soApril || '';
      else if (activeTargetMonth === '03') directMonthCol = st.soMaret || '';
      else if (activeTargetMonth === '02') directMonthCol = st.soFebruari || '';
      else if (activeTargetMonth === '01') directMonthCol = st.soJanuari || '';

      const masterDateVal = masterExtract.rawVal || masterExtract.isoDate || directMonthCol || '';
      const hasMasterDate = Boolean(
        masterExtract.isoDate || 
        (masterDateVal && masterDateVal !== '-' && masterDateVal !== '0' && masterDateVal !== '0-Jan-00' && !masterDateVal.toLowerCase().includes('belum'))
      );
      const formattedMasterDate = masterExtract.displayDate || (masterDateVal ? formatSmartSODate(masterDateVal, '-', activeTargetMonth, activeTargetYear) : '');

      if (activeSched) {
        if (activeSched.scheduledDate === currentDate) {
          scheduleStatusType = 'HARI_INI';
        } else if (activeSched.status === 'Selesai' || activeSched.spvApprovalStatus === 'Disetujui') {
          scheduleStatusType = 'SUDAH_SO';
        } else {
          scheduleStatusType = 'TERJADWAL_LAIN';
        }
      } else if (hasMasterDate) {
        if ((masterExtract.isoDate && masterExtract.isoDate === currentDate) || masterDateVal === currentDate) {
          scheduleStatusType = 'HARI_INI';
        } else {
          scheduleStatusType = 'TERJADWAL_LAIN';
        }
      } else {
        // Kolom blank di master toko bali untuk bulan aktif ini
        scheduleStatusType = 'BELUM_TERJADWAL';
      }

      // Check Zona Hitam from Master Toko columns
      const isHitam = isStoreZonaHitam(st);

      list.push({
        store: st,
        distanceKm: dist,
        scheduleStatusType,
        scheduledDateMaster: formattedMasterDate || (activeSched?.scheduledDate ? formatSmartSODate(activeSched.scheduledDate, '-', activeTargetMonth, activeTargetYear) : ''),
        activeSchedule: activeSched,
        typeSo: st.typeSo || st.qm || 'M',
        zona: isHitam ? 'ZONA HITAM' : 'NON ZONA HITAM',
        isZonaHitam: isHitam,
        saldoToko: st.saldoToko || 0,
        kasToko: st.kasToko,
        soAktiva: st.soAktiva,
        am: st.am,
        as: st.as,
        korlap: st.korlap || activeSched?.officerInCharge,
        coordinatesAvailable: hasCoordinates
      });
    });

    // Flexible Candidate Sorting
    return list.sort((a, b) => {
      // 1. Strict Nearest Distance first (Default & primary user expectation)
      if (candidateSortMode === 'NEAREST_GPS') {
        return a.distanceKm - b.distanceKm;
      }
      // 2. Unassigned (Blank) priority, then distance
      if (candidateSortMode === 'PRIORITY_UNASSIGNED') {
        if (a.scheduleStatusType === 'BELUM_TERJADWAL' && b.scheduleStatusType !== 'BELUM_TERJADWAL') return -1;
        if (b.scheduleStatusType === 'BELUM_TERJADWAL' && a.scheduleStatusType !== 'BELUM_TERJADWAL') return 1;
        return a.distanceKm - b.distanceKm;
      }
      // 3. Highest Saldo first
      if (candidateSortMode === 'HIGHEST_SALDO') {
        const saldoA = typeof a.saldoToko === 'number' ? a.saldoToko : parseFloat(String(a.saldoToko).replace(/[^0-9.-]/g, '')) || 0;
        const saldoB = typeof b.saldoToko === 'number' ? b.saldoToko : parseFloat(String(b.saldoToko).replace(/[^0-9.-]/g, '')) || 0;
        return saldoB - saldoA;
      }
      return a.distanceKm - b.distanceKm;
    });
  }, [selectedSourceStore, stores, schedules, selectedSchedule, candidateSortMode, activeTargetMonth, activeTargetYear]);

  // Extract available Kabupatens with store counts from master stores
  const availableKabupatens = useMemo(() => {
    const map = new Map<string, number>();
    stores.forEach(st => {
      const kab = getCleanKabupaten(st);
      if (kab && kab !== 'BALI' && kab !== '-' && kab !== 'NULL' && kab !== 'UNDEFINED') {
        map.set(kab, (map.get(kab) || 0) + 1);
      }
    });
    return Array.from(map.entries())
      .map(([kab, count]) => ({ name: kab, count }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [stores]);

  // Extract available Kecamatans dynamically filtered by selected Kabupaten
  const availableKecamatans = useMemo(() => {
    const map = new Map<string, number>();
    stores.forEach(st => {
      const storeKab = getCleanKabupaten(st);
      if (filterKabupaten !== 'ALL') {
        const matchesKab = storeKab === filterKabupaten || storeKab.includes(filterKabupaten) || filterKabupaten.includes(storeKab);
        if (!matchesKab) return;
      }
      const kec = getCleanKecamatan(st);
      if (kec && kec !== '-' && kec !== 'NULL' && kec !== 'UNDEFINED') {
        map.set(kec, (map.get(kec) || 0) + 1);
      }
    });
    return Array.from(map.entries())
      .map(([kec, count]) => ({ name: kec, count }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [stores, filterKabupaten]);

  // Dynamic list of Type SO strictly from Master Toko Bali data
  const availableTypeSos = useMemo(() => {
    const counts = new Map<string, number>();
    stores.forEach(st => {
      const raw = (st.typeSo || st.qm || '').trim().toUpperCase();
      const key = raw && raw !== '-' ? raw : 'BLANK';
      counts.set(key, (counts.get(key) || 0) + 1);
    });

    return Array.from(counts.entries())
      .map(([key, count]) => ({
        key,
        label: key === 'BLANK' ? `Tanpa Type / Blank (${count})` : `Type ${key} (${count})`,
        count
      }))
      .sort((a, b) => b.count - a.count);
  }, [stores]);

  // Cascading Kabupaten Selection Handler
  const handleKabupatenChange = (newKab: string) => {
    setFilterKabupaten(newKab);
    if (newKab === 'ALL') {
      setFilterKecamatan('ALL');
    } else if (filterKecamatan !== 'ALL') {
      // Reset kecamatan if it doesn't belong to the newly selected kabupaten
      const existsInNewKab = stores.some(st => {
        const storeKab = getCleanKabupaten(st);
        const matchesKab = storeKab === newKab || storeKab.includes(newKab) || newKab.includes(storeKab);
        if (!matchesKab) return false;
        const storeKec = getCleanKecamatan(st);
        return storeKec === filterKecamatan;
      });
      if (!existsInNewKab) {
        setFilterKecamatan('ALL');
      }
    }
  };

  // Reset all candidate filters
  const hasActiveCandidateFilters = 
    candidateSearchQuery.trim() !== '' || 
    filterKabupaten !== 'ALL' || 
    filterKecamatan !== 'ALL' || 
    filterTypeSo !== 'ALL' || 
    filterSoAktiva !== 'ALL' ||
    filterZonaOnly || 
    maxRadiusKm !== 35 || 
    filterScheduleType !== 'ALL';

  const handleResetCandidateFilters = () => {
    setCandidateSearchQuery('');
    setFilterKabupaten('ALL');
    setFilterKecamatan('ALL');
    setFilterTypeSo('ALL');
    setFilterSoAktiva('ALL');
    setFilterZonaOnly(false);
    setMaxRadiusKm(35);
    setFilterScheduleType('ALL');
  };

  // Filtered Candidate Stores based on SPV criteria
  const filteredCandidates = useMemo(() => {
    return candidateRecommendations.filter(c => {
      // Exclude stores already being audited today
      if (c.scheduleStatusType === 'HARI_INI' || c.scheduleStatusType === 'SUDAH_SO') return false;

      // Filter by Schedule Status (Belum Terjadwal vs Terjadwal di Tanggal Lain)
      if (filterScheduleType === 'BELUM_TERJADWAL' && c.scheduleStatusType !== 'BELUM_TERJADWAL') return false;
      if (filterScheduleType === 'TERJADWAL_LAIN' && c.scheduleStatusType !== 'TERJADWAL_LAIN') return false;

      // Filter by Kabupaten
      if (filterKabupaten !== 'ALL') {
        const storeKab = getCleanKabupaten(c.store);
        const matchesKab = storeKab === filterKabupaten || storeKab.includes(filterKabupaten) || filterKabupaten.includes(storeKab);
        if (!matchesKab) return false;
      }

      // Filter by Kecamatan
      if (filterKecamatan !== 'ALL') {
        const storeKec = getCleanKecamatan(c.store);
        const matchesKec = storeKec === filterKecamatan || storeKec.includes(filterKecamatan) || filterKecamatan.includes(storeKec);
        if (!matchesKec) return false;
      }

      // Filter by Type SO (Strictly synced with Master Toko Bali data)
      if (filterTypeSo !== 'ALL') {
        const rawCandType = (c.typeSo || c.store.typeSo || c.store.qm || '').trim().toUpperCase();
        if (filterTypeSo === 'BLANK') {
          if (rawCandType !== '' && rawCandType !== '-') return false;
        } else {
          if (rawCandType !== filterTypeSo.toUpperCase()) return false;
        }
      }

      // Filter by SO Aktiva (Perlu SO Aktiva vs Non SO Aktiva)
      if (filterSoAktiva !== 'ALL') {
        const isAktiva = isStoreSOAktiva(c.store) || isStoreSOAktiva({ soAktiva: c.soAktiva });
        if (filterSoAktiva === 'SO_AKTIVA' && !isAktiva) return false;
        if (filterSoAktiva === 'NON_SO_AKTIVA' && isAktiva) return false;
      }

      // Filter Zona Hitam Only
      if (filterZonaOnly && !c.isZonaHitam) return false;

      // Filter Radius
      if (maxRadiusKm > 0 && c.coordinatesAvailable && c.distanceKm > maxRadiusKm) return false;

      // Search Query
      if (candidateSearchQuery.trim()) {
        const q = candidateSearchQuery.toLowerCase();
        return (
          c.store.code.toLowerCase().includes(q) ||
          c.store.name.toLowerCase().includes(q) ||
          (c.store.kabupaten && c.store.kabupaten.toLowerCase().includes(q)) ||
          (c.store.kecamatan && c.store.kecamatan.toLowerCase().includes(q)) ||
          (c.store.region && c.store.region.toLowerCase().includes(q)) ||
          (c.korlap && c.korlap.toLowerCase().includes(q)) ||
          c.typeSo.toLowerCase().includes(q)
        );
      }

      return true;
    });
  }, [candidateRecommendations, filterScheduleType, filterKabupaten, filterKecamatan, filterTypeSo, filterSoAktiva, filterZonaOnly, maxRadiusKm, candidateSearchQuery]);

  // Selected replacement store object
  const selectedCandidateObj = useMemo(() => {
    return candidateRecommendations.find(c => c.store.id === selectedCandidateStoreId)?.store || null;
  }, [candidateRecommendations, selectedCandidateStoreId]);

  // Handle Action Execution
  const handleExecuteSwap = () => {
    if (!selectedSchedule || !selectedSourceStore) {
      alert('Pilih toko asal yang minta pindah.');
      return;
    }

    if (!selectedCandidateObj) {
      alert('Pilih toko pengganti dari daftar rekomendasi.');
      return;
    }

    const fullReason = customReason.trim() ? `${reasonCategory} - ${customReason.trim()}` : reasonCategory;

    onApplyRelocation(
      selectedSchedule.id,
      'Pindah Toko',
      fullReason,
      {
        newStore: selectedCandidateObj,
        newDate: targetDateForReplacement || selectedSchedule.scheduledDate,
        newTime: targetTimeForReplacement || '21:00'
      }
    );

    setSwapExecuted({
      originalStore: selectedSourceStore,
      replacementStore: selectedCandidateObj,
      date: targetDateForReplacement || selectedSchedule.scheduledDate,
      reason: fullReason
    });
  };

  // WhatsApp Message Generator for SPV
  const waTemplateText = useMemo(() => {
    if (!selectedSchedule || !selectedSourceStore || !selectedCandidateObj) return '';
    const candDetail = candidateRecommendations.find(c => c.store.id === selectedCandidateObj.id);
    const fullReason = customReason.trim() ? `${reasonCategory} - ${customReason.trim()}` : reasonCategory;

    return `*PEMBERITAHUAN PINDAH TOKO & JADWAL STOCK OPNAME (BALI)*
━━━━━━━━━━━━━━━━━━━━
📅 *Tanggal Pelaksanaan:* ${formatDateIndo(targetDateForReplacement || selectedSchedule.scheduledDate)}
⏰ *Jam Mulai:* ${targetTimeForReplacement || '21:00'} WITA
👤 *Officer / Korlap PIC:* ${selectedSchedule.officerInCharge || selectedSourceStore.korlap || 'Tim Audit'}

❌ *TOKO ASAL (DIBATALKAN/PINDAH):*
• *Kode/Nama:* [${selectedSourceStore.code}] ${selectedSourceStore.name}
• *Wilayah:* ${selectedSourceStore.kabupaten || selectedSourceStore.region}
• *Alasan Pindah:* ${fullReason}

🔄 *REKOMENDASI TOKO PENGGANTI (FIX):*
• *Kode/Nama:* [${selectedCandidateObj.code}] ${selectedCandidateObj.name}
• *Wilayah/Kec:* ${selectedCandidateObj.kabupaten || selectedCandidateObj.region} (${selectedCandidateObj.district || ''})
• *Jarak dari Toko Asal:* ${candDetail ? `${candDetail.distanceKm} km` : '-'}
• *Type SO:* ${selectedCandidateObj.typeSo || selectedCandidateObj.qm || 'M'} | *SO Aktiva:* ${getSOAktivaLabel(selectedCandidateObj)} | *Zona:* ${selectedCandidateObj.zona || 'REGULER'}
• *Saldo Toko / Stock:* ${typeof selectedCandidateObj.saldoToko === 'number' ? formatRupiah(selectedCandidateObj.saldoToko) : (selectedCandidateObj.saldoToko || '-')}
• *Status Jadwal Awal:* ${candDetail?.scheduleStatusType === 'BELUM_TERJADWAL' ? 'Belum Terjadwal (Kolom Blank Master)' : `Terjadwal (${candDetail?.scheduledDateMaster || '-'})`}

_Master Toko Bali & Jadwal telah disinkronkan otomatis oleh SPV._`;
  }, [selectedSchedule, selectedSourceStore, selectedCandidateObj, candidateRecommendations, targetDateForReplacement, targetTimeForReplacement, reasonCategory, customReason]);

  const handleCopyWA = () => {
    if (!waTemplateText) return;
    navigator.clipboard.writeText(waTemplateText);
    setCopiedWA(true);
    setTimeout(() => setCopiedWA(false), 3000);
  };

  return (
    <div className="space-y-4">
      {/* Header Banner - Mobile Optimized */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 sm:p-5 rounded-2xl border border-indigo-700/50 shadow-md relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-300 shrink-0">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-wider bg-indigo-500/30 text-indigo-200 px-2 py-0.5 rounded border border-indigo-400/30">
                  SPV ASSISTANT
                </span>
                <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Rekomendasi Pintar GPS
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-white mt-0.5">
                Cek Opsi Pindah Toko & Rekomendasi Pengganti
              </h2>
              <p className="text-xs text-slate-300">
                Pilih toko yang bermasalah/minta pindah, sistem akan merekomendasikan toko terdekat yang belum terjadwal (kolom blank) atau opsi swap.
              </p>
            </div>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="self-end sm:self-center p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Success Notification if Swap Executed */}
      {swapExecuted && (
        <div className="bg-emerald-950/80 border border-emerald-500/50 rounded-2xl p-4 text-emerald-100 shadow-md animate-in fade-in slide-in-from-top duration-300">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
              <div>
                <h4 className="font-extrabold text-sm text-emerald-200">
                  Perpindahan Toko Berhasil Diterapkan & Master Toko Disinkronkan!
                </h4>
                <p className="text-xs text-emerald-300 mt-0.5">
                  Toko <strong>[{swapExecuted.originalStore.code}] {swapExecuted.originalStore.name}</strong> berhasil digantikan oleh <strong>[{swapExecuted.replacementStore.code}] {swapExecuted.replacementStore.name}</strong> untuk tanggal <strong>{formatDateIndo(swapExecuted.date)}</strong>.
                </p>
              </div>
            </div>
            <button
              onClick={handleCopyWA}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5 shrink-0 shadow-xs cursor-pointer"
            >
              {copiedWA ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedWA ? 'Tersalin!' : 'Salin Format WA'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Smart Month Selector Bar for Reading Master Toko Bali */}
      <div className="bg-white rounded-2xl border border-indigo-200 shadow-xs p-3.5 sm:p-4 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-100 text-indigo-900 px-2 py-0.5 rounded border border-indigo-200">
                  PEMILIHAN BULAN CERDAS MASTER BALI
                </span>
                <span className="text-[11px] font-bold text-slate-500">
                  Membaca Kolom: <strong className="text-indigo-700 font-mono">{activeMonthConfig.standardCol}</strong>
                </span>
              </div>
              <h3 className="text-sm sm:text-base font-black text-slate-900 mt-0.5 flex items-center gap-2">
                <span>Bulan Penjadwalan: </span>
                <span className="text-indigo-600 font-black">{activeMonthConfig.name} {activeTargetYear}</span>
              </h3>
            </div>
          </div>

          {/* Month & Year Selectors */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 bg-indigo-50 border border-indigo-300 rounded-xl px-2.5 py-1.5">
              <span className="text-[10px] font-black text-indigo-800 uppercase tracking-wider">Pilih Bulan:</span>
              <select
                value={selectedRelocationMonth}
                onChange={(e) => setSelectedRelocationMonth(e.target.value)}
                className="bg-white border border-indigo-300 font-black text-xs text-indigo-950 rounded-lg px-2.5 py-1 cursor-pointer hover:border-indigo-500 focus:ring-2 focus:ring-indigo-500 outline-hidden"
              >
                {MASTER_BALI_MONTH_CONFIGS.map(cfg => {
                  const count = monthStats[cfg.month]?.scheduledCount || 0;
                  return (
                    <option key={cfg.month} value={cfg.month}>
                      {cfg.month === '10' ? '⭐ ' : ''}{cfg.name} ({cfg.standardCol}) — {count} toko terjadwal
                    </option>
                  );
                })}
              </select>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">Tahun:</span>
              <select
                value={selectedRelocationYear}
                onChange={(e) => setSelectedRelocationYear(e.target.value)}
                className="bg-white border border-slate-300 font-bold text-xs text-slate-800 rounded-lg px-2 py-1 cursor-pointer focus:ring-2 focus:ring-indigo-500 outline-hidden"
              >
                <option value="2026">2026</option>
                <option value="2025">2025</option>
                <option value="2027">2027</option>
              </select>
            </div>
          </div>
        </div>

        {/* Quick Month Switcher Buttons + Status Summary */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mr-1">
              Akses Cepat:
            </span>
            {MASTER_BALI_MONTH_CONFIGS.slice(0, 5).map(cfg => {
              const isSelected = activeTargetMonth === cfg.month;
              const count = monthStats[cfg.month]?.scheduledCount || 0;
              return (
                <button
                  key={cfg.month}
                  type="button"
                  onClick={() => setSelectedRelocationMonth(cfg.month)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow-xs ring-2 ring-indigo-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <span>{cfg.name}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected ? 'bg-indigo-800 text-indigo-100' : 'bg-white text-slate-600 border border-slate-200'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-600">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span><strong>{monthStats[activeTargetMonth]?.blankCount || 0}</strong> Belum Terjadwal (Blank)</span>
            </span>
            <span className="text-slate-300">•</span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
              <span><strong>{monthStats[activeTargetMonth]?.scheduledCount || 0}</strong> Terjadwal ({activeMonthConfig.name})</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main 2-Column Workflow Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* LEFT COLUMN: Step 1 (Pilih Toko Asal) & Step 2 (Alasan Pindah) */}
        <div className="lg:col-span-4 space-y-4">
          
          {/* STEP 1: Pilih Toko Yang Minta Pindah */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center">1</span>
                <h3 className="font-extrabold text-slate-900 text-xs sm:text-sm">
                  Pilih Toko Yang Minta Pindah
                </h3>
              </div>
              <span className="text-[10px] font-bold text-slate-500 font-mono">
                {filteredSourceSchedules.length} Toko Aktif
              </span>
            </div>

            {/* Quick Status Tab Switcher for Source Schedules */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setSourceFilterStatus('ALL')}
                className={`flex-1 py-1 rounded-lg transition text-center ${
                  sourceFilterStatus === 'ALL' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semua ({eligibleSourceSchedules.length})
              </button>
              {needRelocationCount > 0 && (
                <button
                  type="button"
                  onClick={() => setSourceFilterStatus('NEED_RELOCATION')}
                  className={`flex-1 py-1 rounded-lg transition flex items-center justify-center gap-1 ${
                    sourceFilterStatus === 'NEED_RELOCATION' ? 'bg-rose-600 text-white shadow-2xs' : 'text-rose-700 hover:bg-rose-50'
                  }`}
                >
                  <span>🚨 Butuh Relokasi</span>
                  <span className="bg-white text-rose-700 text-[10px] px-1 rounded-full font-black">{needRelocationCount}</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setSourceFilterStatus('ACTIVE')}
                className={`flex-1 py-1 rounded-lg transition text-center ${
                  sourceFilterStatus === 'ACTIVE' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Jadwal Aktif
              </button>
            </div>

            {/* Month Filter Selector for Step 1 Source Schedules */}
            <div className="flex items-center justify-between text-xs bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded-xl">
              <div className="flex items-center gap-1.5 text-slate-700 font-bold text-[11px]">
                <Calendar className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span>Bulan Jadwal: <strong>{activeMonthConfig.name} {activeTargetYear}</strong></span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRelocationMonth(selectedRelocationMonth === 'ALL' ? (defaultCalM || '10') : 'ALL')}
                className="text-[10px] font-extrabold text-indigo-600 hover:text-indigo-800 transition"
              >
                {selectedRelocationMonth === 'ALL' ? `Batasi ${activeMonthConfig.name}` : 'Tampilkan Semua Bulan'}
              </button>
            </div>

            {/* Date & Kabupaten Quick Filter */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs">
              <div className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <select
                  value={sourceFilterDate}
                  onChange={(e) => setSourceFilterDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs font-bold text-slate-800"
                >
                  <option value="ALL">Semua Tanggal</option>
                  {availableScheduleDates.map(d => (
                    <option key={d} value={d}>{formatDateIndo(d)}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <select
                  value={sourceFilterKabupaten}
                  onChange={(e) => setSourceFilterKabupaten(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs font-bold text-slate-800"
                >
                  <option value="ALL">Semua Kab.</option>
                  {availableKabupatens.map(k => (
                    <option key={k.name} value={k.name}>{k.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Quick Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Cari kode/nama toko asal..."
                value={sourceSearchQuery}
                onChange={(e) => setSourceSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden"
              />
            </div>

            {/* Source Store List Selection (Scrollable) */}
            <div className="max-h-56 overflow-y-auto space-y-1.5 pr-1 text-xs">
              {filteredSourceSchedules.map(sch => {
                const isSelected = (selectedSchedule?.id === sch.id);
                const stObj = stores.find(s => s.code === sch.storeCode || s.id === sch.storeId);
                const isHitam = isStoreZonaHitam(stObj);

                return (
                  <div
                    key={sch.id}
                    onClick={() => {
                      setSelectedSourceScheduleId(sch.id);
                      setSelectedCandidateStoreId('');
                    }}
                    className={`p-2.5 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-rose-50 border-rose-400 ring-2 ring-rose-400/20 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/70'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-1.5">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-rose-900 bg-rose-100/80 px-1.5 py-0.2 rounded text-[10px]">
                            {sch.storeCode}
                          </span>
                          {isHitam && (
                            <span className="text-[9px] font-black bg-rose-600 text-white px-1.5 py-0.2 rounded-full">
                              ZONA HITAM
                            </span>
                          )}
                          {sch.status === 'Pindah Toko' && (
                            <span className="text-[9px] font-black bg-amber-500 text-white px-1.5 py-0.2 rounded-full">
                              🚨 LAPOR PINDAH
                            </span>
                          )}
                          {sch.status === 'Gagal SO' && (
                            <span className="text-[9px] font-black bg-rose-600 text-white px-1.5 py-0.2 rounded-full">
                              🚨 GAGAL SO
                            </span>
                          )}
                          {isStoreSOAktiva(stObj || sch) && (
                            <span className="text-[9px] font-black bg-purple-100 text-purple-800 border border-purple-300 px-1.5 py-0.2 rounded-full">
                              SO AKTIVA
                            </span>
                          )}
                        </div>
                        <p className="font-extrabold text-slate-900 text-xs mt-0.5 line-clamp-1">
                          {sch.storeName}
                        </p>
                      </div>
                      <span className="text-[10px] font-bold text-slate-500 font-mono shrink-0">
                        {sch.scheduledDate ? sch.scheduledDate.slice(5) : '-'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1.5 pt-1 border-t border-slate-100">
                      <span className="truncate max-w-[130px]">{stObj?.kabupaten || sch.region}</span>
                      <span className="font-medium text-indigo-700">{sch.officerInCharge || stObj?.korlap || 'Korlap'}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Selected Store Detail Card */}
            {selectedSourceStore && (
              <div className="bg-slate-900 text-white p-3 rounded-xl border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase">
                  <span>Detail Toko Asal Terpilih</span>
                  <span className="text-amber-400 font-mono">{selectedSourceStore.code}</span>
                </div>
                <p className="font-black text-sm text-white">{selectedSourceStore.name}</p>
                
                <div className="grid grid-cols-2 gap-1.5 text-[11px] text-slate-300 pt-1 border-t border-slate-800">
                  <div>Wilayah: <strong className="text-white">{selectedSourceStore.kabupaten || selectedSourceStore.city || selectedSourceStore.region}</strong></div>
                  <div>Type SO: <strong className="text-amber-300">{selectedSourceStore.typeSo || selectedSourceStore.qm || 'M'}</strong></div>
                  <div>SO Aktiva: <strong className={isStoreSOAktiva(selectedSourceStore) ? 'text-purple-300 font-black' : 'text-slate-300'}>{getSOAktivaLabel(selectedSourceStore)}</strong></div>
                  <div>Zona: <strong className={selectedSourceStore.isZonaHitam ? 'text-rose-400' : 'text-slate-200'}>{selectedSourceStore.zona || 'NON ZONA HITAM'}</strong></div>
                  <div>Stock: <strong className="text-emerald-300">{typeof selectedSourceStore.saldoToko === 'number' ? formatRupiah(selectedSourceStore.saldoToko) : (selectedSourceStore.saldoToko || '-')}</strong></div>
                  <div>AM / AS: <strong className="text-white">{selectedSourceStore.am || '-'} / {selectedSourceStore.as || '-'}</strong></div>
                  <div className="col-span-2">Korlap: <strong className="text-indigo-300">{selectedSchedule?.officerInCharge || selectedSourceStore.korlap || '-'}</strong></div>
                </div>

                {selectedSourceStore.latitude && selectedSourceStore.longitude ? (
                  <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 bg-slate-800 px-2 py-1 rounded">
                    <MapPin className="w-3 h-3 text-emerald-400" />
                    <span>GPS Siap: {selectedSourceStore.latitude.toFixed(4)}, {selectedSourceStore.longitude.toFixed(4)}</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-[10px] text-amber-400 bg-slate-800 px-2 py-1 rounded">
                    <AlertTriangle className="w-3 h-3 text-amber-400" />
                    <span>Koordinat belum terdaftar (Jarak menggunakan estimasi wilayah)</span>
                  </div>
                )}
              </div>
            )}

          </div>

          {/* STEP 2: Alasan Pindah & Tanggal Pelaksanaan */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 space-y-3">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
              <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center">2</span>
              <h3 className="font-extrabold text-slate-900 text-xs sm:text-sm">
                Alasan Pindah & Waktu Audit
              </h3>
            </div>

            {/* Quick Reason Selector */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Kategori Alasan Pindah:
              </label>
              <select
                value={reasonCategory}
                onChange={(e) => setReasonCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-800"
              >
                <option value="Akses Jalan / Cuaca Ekstrem">Akses Jalan / Cuaca Ekstrem</option>
                <option value="Toko Sedang Renovasi / Perbaikan Listrik">Toko Sedang Renovasi / Perbaikan Listrik</option>
                <option value="Kendala Jaringan / Server Toko Offline">Kendala Jaringan / Server Toko Offline</option>
                <option value="Izin Pihak Mall / Pengelola Gedung">Izin Pihak Mall / Pengelola Gedung</option>
                <option value="Personil / Kendala Jumlah Auditor">Personil / Kendala Jumlah Auditor</option>
                <option value="Permintaan Khusus Area Manager / Toko">Permintaan Khusus Area Manager / Toko</option>
                <option value="Lainnya">Lainnya (Tuliskan di bawah)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Keterangan Tambahan (Opsional):
              </label>
              <textarea
                rows={2}
                placeholder="Contoh: Toko banjir setinggi 30cm, dialihkan ke toko terdekat..."
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  Tanggal Pengganti:
                </label>
                <input
                  type="date"
                  value={targetDateForReplacement}
                  onChange={(e) => setTargetDateForReplacement(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs font-bold text-slate-800"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  Jam Mulai SO:
                </label>
                <input
                  type="time"
                  value={targetTimeForReplacement}
                  onChange={(e) => setTargetTimeForReplacement(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs font-bold text-slate-800"
                />
              </div>
            </div>

          </div>

        </div>

        {/* RIGHT COLUMN: Step 3 (Rekomendasi Toko Terdekat & Opsi Pindah) */}
        <div className="lg:col-span-8 space-y-4">
          
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-5 space-y-4">
            
            {/* Step 3 Header & Filter Tabs */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center">3</span>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base flex items-center gap-2">
                    <span>Rekomendasi Toko Pengganti</span>
                    <span className="bg-emerald-100 text-emerald-800 text-[11px] font-mono px-2 py-0.5 rounded-full font-bold">
                      {filteredCandidates.length} Opsi
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Diurutkan otomatis dari <strong>Jarak GPS Terdekat</strong> & <strong>Belum Terjadwal (Kolom Blank {getFullMonthNameIndo(activeTargetMonth)})</strong>
                  </p>
                </div>
              </div>

              {/* Quick Status Tab Switcher */}
              <div className="flex flex-wrap items-center gap-1.5">
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => setFilterScheduleType('ALL')}
                    className={`px-2.5 py-1 rounded-lg transition ${
                      filterScheduleType === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Semua ({candidateRecommendations.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterScheduleType('BELUM_TERJADWAL')}
                    className={`px-2.5 py-1 rounded-lg transition flex items-center gap-1 ${
                      filterScheduleType === 'BELUM_TERJADWAL' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-300" />
                    <span>Belum Terjadwal ({candidateRecommendations.filter(c => c.scheduleStatusType === 'BELUM_TERJADWAL').length})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterScheduleType('TERJADWAL_LAIN')}
                    className={`px-2.5 py-1 rounded-lg transition flex items-center gap-1 ${
                      filterScheduleType === 'TERJADWAL_LAIN' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-300" />
                    <span>Tukar Jadwal ({candidateRecommendations.filter(c => c.scheduleStatusType === 'TERJADWAL_LAIN').length})</span>
                  </button>
                </div>

                {/* Sorting Mode Selector */}
                <div className="flex items-center gap-1 bg-indigo-50 border border-indigo-100 p-1 rounded-xl text-[11px] font-bold text-indigo-900">
                  <span className="px-1 text-[10px] text-indigo-500 uppercase tracking-wider font-extrabold hidden sm:inline">Urutan:</span>
                  <button
                    type="button"
                    onClick={() => setCandidateSortMode('NEAREST_GPS')}
                    className={`px-2 py-0.5 rounded-lg transition flex items-center gap-1 cursor-pointer ${
                      candidateSortMode === 'NEAREST_GPS' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-indigo-700 hover:bg-indigo-100/70'
                    }`}
                    title="Urutkan dari jarak GPS terdekat ke terjauh"
                  >
                    <Navigation className="w-3 h-3" />
                    <span>Jarak Terdekat</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCandidateSortMode('PRIORITY_UNASSIGNED')}
                    className={`px-2 py-0.5 rounded-lg transition cursor-pointer ${
                      candidateSortMode === 'PRIORITY_UNASSIGNED' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-indigo-700 hover:bg-indigo-100/70'
                    }`}
                    title="Prioritaskan toko belum terjadwal, lalu jarak terdekat"
                  >
                    <span>⭐ Belum Terjadwal</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCandidateSortMode('HIGHEST_SALDO')}
                    className={`px-2 py-0.5 rounded-lg transition cursor-pointer ${
                      candidateSortMode === 'HIGHEST_SALDO' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-indigo-700 hover:bg-indigo-100/70'
                    }`}
                    title="Urutkan dari nilai saldo toko terbesar"
                  >
                    <span>Saldo Terbesar</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Intelligent Reading Column Feedback Badge */}
            <div className="bg-gradient-to-r from-indigo-50 via-blue-50 to-indigo-50 border border-indigo-200 rounded-xl p-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-slate-700">
                  Membaca Kolom: <strong className="text-indigo-950 font-black">{activeMonthConfig.standardCol}</strong> di Master Toko Bali
                </span>
              </div>
              <div className="flex items-center gap-2 text-[11px] flex-wrap">
                <span className="bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.5 rounded-full border border-emerald-300">
                  🟢 {monthStats[activeTargetMonth]?.blankCount || 0} Belum Terjadwal (Kolom Blank)
                </span>
                <span className="bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded-full border border-indigo-300">
                  🟡 {monthStats[activeTargetMonth]?.scheduledCount || 0} Terjadwal ({activeMonthConfig.name})
                </span>
              </div>
            </div>

            {/* Smart Filters Bar */}
            <div className="space-y-2.5">
              {/* Search Bar + Reset Filter Button */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Cari kode toko, nama toko, alamat, korlap..."
                    value={candidateSearchQuery}
                    onChange={(e) => setCandidateSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 outline-hidden"
                  />
                  {candidateSearchQuery && (
                    <button 
                      onClick={() => setCandidateSearchQuery('')}
                      className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {hasActiveCandidateFilters && (
                  <button
                    type="button"
                    onClick={handleResetCandidateFilters}
                    className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow-2xs"
                    title="Reset semua filter pencarian"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Reset Filter</span>
                  </button>
                )}
              </div>

              {/* Filter Dropdowns Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-2 text-xs">
                
                {/* Filter Kolom Bulan Master Toko */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-indigo-600" />
                    <span>Bulan Master:</span>
                  </label>
                  <select
                    value={selectedRelocationMonth}
                    onChange={(e) => setSelectedRelocationMonth(e.target.value)}
                    className="w-full bg-indigo-50/70 border border-indigo-300 ring-1 ring-indigo-400/30 rounded-xl px-2.5 py-1.5 font-black text-xs text-indigo-950 focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                  >
                    {MASTER_BALI_MONTH_CONFIGS.map(cfg => {
                      const count = monthStats[cfg.month]?.scheduledCount || 0;
                      return (
                        <option key={cfg.month} value={cfg.month}>
                          {cfg.month === '10' ? '⭐ ' : ''}{cfg.name} ({count})
                        </option>
                      );
                    })}
                  </select>
                </div>

                {/* Filter Kabupaten */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-indigo-600" />
                    <span>Kabupaten:</span>
                  </label>
                  <select
                    value={filterKabupaten}
                    onChange={(e) => handleKabupatenChange(e.target.value)}
                    className={`w-full bg-slate-50 border rounded-xl px-2.5 py-1.5 font-bold text-xs transition ${
                      filterKabupaten !== 'ALL'
                        ? 'border-indigo-500 bg-indigo-50/50 text-indigo-900 ring-1 ring-indigo-500'
                        : 'border-slate-200 text-slate-800'
                    }`}
                  >
                    <option value="ALL">Semua Kabupaten ({stores.length})</option>
                    {availableKabupatens.map(k => (
                      <option key={k.name} value={k.name}>
                        {k.name} ({k.count})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Filter Kecamatan (Dynamic from selected Kabupaten) */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 flex items-center gap-1">
                    <Building2 className="w-3 h-3 text-indigo-600" />
                    <span>Kecamatan:</span>
                  </label>
                  <select
                    value={filterKecamatan}
                    onChange={(e) => setFilterKecamatan(e.target.value)}
                    className={`w-full bg-slate-50 border rounded-xl px-2.5 py-1.5 font-bold text-xs transition ${
                      filterKecamatan !== 'ALL'
                        ? 'border-indigo-500 bg-indigo-50/50 text-indigo-900 ring-1 ring-indigo-500'
                        : 'border-slate-200 text-slate-800'
                    }`}
                  >
                    <option value="ALL">
                      {filterKabupaten !== 'ALL' 
                        ? `Semua Kec. (${availableKecamatans.reduce((acc, curr) => acc + curr.count, 0)})` 
                        : `Semua Kecamatan (${availableKecamatans.length})`
                      }
                    </option>
                    {availableKecamatans.map(kc => (
                      <option key={kc.name} value={kc.name}>
                        {kc.name} ({kc.count})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Type SO Filter (Synced directly with Master Toko Bali) */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 flex items-center gap-1">
                    <Layers className="w-3 h-3 text-indigo-600" />
                    <span>Type SO:</span>
                  </label>
                  <select
                    value={filterTypeSo}
                    onChange={(e) => setFilterTypeSo(e.target.value)}
                    className={`w-full bg-slate-50 border rounded-xl px-2.5 py-1.5 font-bold text-xs transition ${
                      filterTypeSo !== 'ALL'
                        ? 'border-indigo-500 bg-indigo-50/50 text-indigo-900 ring-1 ring-indigo-500'
                        : 'border-slate-200 text-slate-800'
                    }`}
                  >
                    <option value="ALL">Semua Type SO</option>
                    {availableTypeSos.map(t => (
                      <option key={t.key} value={t.key}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Filter SO Aktiva */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 flex items-center gap-1">
                    <Tag className="w-3 h-3 text-purple-600" />
                    <span>SO Aktiva:</span>
                  </label>
                  <select
                    value={filterSoAktiva}
                    onChange={(e) => setFilterSoAktiva(e.target.value as any)}
                    className={`w-full bg-slate-50 border rounded-xl px-2.5 py-1.5 font-bold text-xs transition ${
                      filterSoAktiva !== 'ALL'
                        ? 'border-purple-500 bg-purple-50/50 text-purple-900 ring-1 ring-purple-500'
                        : 'border-slate-200 text-slate-800'
                    }`}
                  >
                    <option value="ALL">Semua SO Aktiva</option>
                    <option value="SO_AKTIVA">🏷️ Perlu SO Aktiva (SO AKTIVA)</option>
                    <option value="NON_SO_AKTIVA">NON SO AKTIVA</option>
                  </select>
                </div>

                {/* Max Radius */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 flex items-center gap-1">
                    <Navigation className="w-3 h-3 text-indigo-600" />
                    <span>Radius Jarak:</span>
                  </label>
                  <select
                    value={maxRadiusKm}
                    onChange={(e) => setMaxRadiusKm(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 font-bold text-slate-800"
                  >
                    <option value={10}>Radius &lt; 10 km</option>
                    <option value={20}>Radius &lt; 20 km</option>
                    <option value={35}>Radius &lt; 35 km</option>
                    <option value={60}>Radius &lt; 60 km</option>
                    <option value={0}>Semua Jarak</option>
                  </select>
                </div>

                {/* Zona Hitam Toggle */}
                <div className="flex flex-col justify-end">
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 invisible">
                    Zona:
                  </label>
                  <button
                    type="button"
                    onClick={() => setFilterZonaOnly(!filterZonaOnly)}
                    className={`w-full py-1.5 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 border cursor-pointer ${
                      filterZonaOnly
                        ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                    title="Filter Toko Zona Hitam Saja"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                    <span>{filterZonaOnly ? 'Zona Hitam (Aktif)' : 'Zona Hitam'}</span>
                  </button>
                </div>

              </div>
            </div>

            {/* Candidates Card List (Scrollable, mobile responsive) */}
            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
              {filteredCandidates.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300 space-y-3">
                  <Navigation className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-sm font-bold text-slate-700">Tidak ada toko rekomendasi yang cocok dengan filter aktif</p>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Mungkin radius {maxRadiusKm > 0 ? `${maxRadiusKm} km` : ''} terlalu sempit atau filter wilayah terlalu spesifik.
                  </p>
                  <div className="flex flex-wrap justify-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setMaxRadiusKm(0)}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                    >
                      Buka Semua Radius Jarak
                    </button>
                    <button
                      type="button"
                      onClick={handleResetCandidateFilters}
                      className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                    >
                      Reset Semua Filter
                    </button>
                  </div>
                </div>
              ) : (
                filteredCandidates.map((cand) => {
                  const isSelected = (selectedCandidateStoreId === cand.store.id);
                  const isBelumTerjadwal = cand.scheduleStatusType === 'BELUM_TERJADWAL';
                  const kabDisplay = getCleanKabupaten(cand.store) || cand.store.region || 'BALI';
                  const kecDisplay = getCleanKecamatan(cand.store);

                  return (
                    <div
                      key={cand.store.id}
                      onClick={() => setSelectedCandidateStoreId(cand.store.id)}
                      className={`p-3.5 rounded-2xl border transition cursor-pointer relative overflow-hidden ${
                        isSelected
                          ? 'bg-indigo-50/90 border-indigo-500 ring-2 ring-indigo-500/30 shadow-md'
                          : 'bg-white border-slate-200 hover:border-indigo-300 hover:bg-slate-50/80'
                      }`}
                    >
                      {/* Top Badges Bar */}
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {/* Store Code */}
                          <span className="font-mono font-black text-xs px-2 py-0.5 rounded-md bg-slate-900 text-white">
                            {cand.store.code}
                          </span>

                          {/* Schedule Status Badge */}
                          {isBelumTerjadwal ? (
                            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              🟢 Belum Terjadwal (Kolom Blank {activeMonthConfig.name})
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-300 flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                              🟡 Terjadwal ({activeMonthConfig.name}): {cand.scheduledDateMaster || '-'} (Opsi Tukar)
                            </span>
                          )}

                          {/* Type SO Badge */}
                          {cand.typeSo ? (
                            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-lg bg-amber-100 text-amber-900 border border-amber-300">
                              Type {cand.typeSo}
                            </span>
                          ) : (
                            <span className="text-[10px] font-medium px-2 py-0.5 rounded-lg bg-slate-100 text-slate-500 border border-slate-200">
                              Type -
                            </span>
                          )}

                          {/* SO Aktiva Badge */}
                          {isStoreSOAktiva(cand.store) || isStoreSOAktiva({ soAktiva: cand.soAktiva }) ? (
                            <span className="text-[10px] font-black px-2 py-0.5 rounded-lg bg-purple-100 text-purple-800 border border-purple-300 flex items-center gap-1 shadow-2xs">
                              🏷️ SO AKTIVA
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg bg-slate-100 text-slate-500 border border-slate-200">
                              NON SO AKTIVA
                            </span>
                          )}

                          {/* Zona Hitam Badge */}
                          {cand.isZonaHitam && (
                            <span className="text-[10px] font-black px-2 py-0.5 rounded-lg bg-rose-600 text-white flex items-center gap-1">
                              <ShieldAlert className="w-3 h-3" /> ZONA HITAM
                            </span>
                          )}
                        </div>

                        {/* Distance Badge */}
                        <div className="flex items-center gap-1.5 bg-slate-900 text-white px-2.5 py-1 rounded-xl font-mono text-xs font-bold">
                          <Navigation className="w-3 h-3 text-indigo-400" />
                          <span>{cand.distanceKm < 1 ? `${Math.round(cand.distanceKm * 1000)} m` : `${cand.distanceKm.toFixed(1)} km`}</span>
                        </div>
                      </div>

                      {/* Store Title & Location */}
                      <div className="mt-2">
                        <h4 className="font-extrabold text-sm text-slate-900">
                          {cand.store.name}
                        </h4>
                        <p className="text-xs text-slate-600 flex items-center gap-1.5 mt-0.5 flex-wrap">
                          <MapPin className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                          <span className="font-bold text-slate-800">
                            Kab. {kabDisplay}
                          </span>
                          {kecDisplay && (
                            <span className="bg-indigo-50 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded-md border border-indigo-100">
                              Kec. {kecDisplay}
                            </span>
                          )}
                          {cand.store.address && (
                            <span className="text-slate-500 truncate max-w-xs block sm:inline">
                              - {cand.store.address}
                            </span>
                          )}
                        </p>
                      </div>

                      {/* Detail Metrics Row */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-slate-600 mt-2.5 pt-2 border-t border-slate-100">
                        <div>
                          <span className="text-[10px] text-slate-400 block">Saldo Toko / Stock</span>
                          <strong className="text-slate-900 font-mono">
                            {typeof cand.saldoToko === 'number' ? formatRupiah(cand.saldoToko) : (cand.saldoToko || '-')}
                          </strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">AM / AS</span>
                          <strong className="text-slate-900">{cand.am || '-'}{cand.as ? ` / ${cand.as}` : ''}</strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">Korlap / Officer</span>
                          <strong className="text-indigo-700">{cand.korlap || 'Master Personil'}</strong>
                        </div>
                        <div className="text-right flex items-center justify-end">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedCandidateStoreId(cand.store.id);
                            }}
                            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition flex items-center gap-1 cursor-pointer ${
                              isSelected
                                ? 'bg-indigo-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-700 hover:bg-indigo-100 hover:text-indigo-900'
                            }`}
                          >
                            {isSelected ? <Check className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                            <span>{isSelected ? 'Toko Dipilih' : 'Pilih Toko'}</span>
                          </button>
                        </div>
                      </div>

                    </div>
                  );
                })
              )}
            </div>

            {/* Bottom Action Execution Bar */}
            <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="text-xs text-slate-600">
                {selectedCandidateObj ? (
                  <p>
                    Toko Pengganti Terpilih: <strong className="text-indigo-700">[{selectedCandidateObj.code}] {selectedCandidateObj.name}</strong>
                  </p>
                ) : (
                  <p className="text-slate-400 italic">
                    Silakan klik salah satu toko rekomendasi di atas untuk menggantikan jadwal.
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2">
                {selectedCandidateObj && (
                  <button
                    type="button"
                    onClick={handleCopyWA}
                    className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedWA ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedWA ? 'Tersalin' : 'Format WA'}</span>
                  </button>
                )}

                <button
                  type="button"
                  disabled={!selectedSchedule || !selectedCandidateObj}
                  onClick={handleExecuteSwap}
                  className={`px-5 py-2.5 rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-2 shadow-md cursor-pointer ${
                    selectedSchedule && selectedCandidateObj
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Terapkan Pindah Toko & Sinkronisasi Master</span>
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
